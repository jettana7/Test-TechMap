export const SHEET_TECHNICIANS = 'Technicians';
export const SHEET_AUDIT = 'AuditLog';

export const AUDIT_HEADERS: readonly string[] = [
  'เวลา',
  'ผู้ใช้',
  'การกระทำ',
  'id ช่าง',
  'สรุป',
];

export const PROP_SPREADSHEET_ID = 'SPREADSHEET_ID';
export const PROP_DATA_VERSION = 'DATA_VERSION';