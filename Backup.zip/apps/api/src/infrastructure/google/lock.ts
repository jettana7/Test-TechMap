export function withLock<T>(work: () => T, timeoutMs = 15000): T {
  const lock = LockService.getScriptLock();
  lock.waitLock(timeoutMs);
  try {
    return work();
  } finally {
    lock.releaseLock();
  }
}