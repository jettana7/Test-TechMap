export type DomainErrorCode =
  | 'VALIDATION'
  | 'DUPLICATE_CODE'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'FORBIDDEN';

export class DomainError extends Error {
  public readonly code: DomainErrorCode;

  constructor(code: DomainErrorCode, message: string) {
    super(message);
    this.name = 'DomainError';
    this.code = code;
  }
}