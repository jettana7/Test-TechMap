import type { Technician } from '@technician-map/shared';

export interface TechnicianRepository {
  /** ช่างที่ยังไม่ถูกลบ */
  list(): Technician[];
  findById(id: string): Technician | undefined;
  insert(technician: Technician): void;
  update(technician: Technician): void;
  softDelete(id: string, deletedAt: string, deletedBy: string): void;
}

export interface Clock {
  nowIso(): string;
}

export interface IdGenerator {
  next(): string;
}

export interface AuditEntry {
  readonly timestamp: string;
  readonly actor: string;
  readonly action: 'CREATE' | 'UPDATE' | 'DELETE';
  readonly technicianId: string;
  readonly summary: string;
}

export interface AuditLogger {
  record(entry: AuditEntry): void;
}

export interface DataVersion {
  current(): number;
  /** เพิ่มเลข version ต้องเรียกภายใน lock เพื่อไม่ให้ค่าหาย */
  bump(): number;
}